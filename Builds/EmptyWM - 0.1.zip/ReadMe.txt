The readme has yet to be fully written

How this program works:

It executes itself into the System Tray as an icon and then goes silent. If you ever want to quit just click on the icon and choose "Exit" (please do not attempt to kill the program from the task manager because it will break some of your windows).

Ctrl + Shift + Q : Toggle titlebar/borders in currently focused window (any windows minus some special windows).

Alt + Right click drag : Resize the currently focused window with the mouse.

Alt + Left click drag : Move the currently focused window with the mouse.


TODO:

- Fix minor bugs and annoying issues
- Add custom settings for users 
- Possibly add more menu context 
- Add a versioning system (1.0, 1.1, etc etc). So far I just keep track of them in the .zip files
- New features???
